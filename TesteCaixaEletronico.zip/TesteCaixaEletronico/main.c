#include <stdlib.h>
#include <stdio.h>

float saldo = 0.0;

void deposito(float valor) {
    saldo += valor;
    printf("----------------------------------------------------\n");
    printf("\n Deposito de %.2f realizado com sucesso!\n", valor);
    printf("\n----------------------------------------------------");
}

void saque(float valor) {
    if (valor > saldo) {
        printf("----------------------------------------------------\n");
        printf("\n Saldo insuficiente!\n");
    printf("\n----------------------------------------------------");
    } else {
        saldo -= valor;
        printf("----------------------------------------------------\n");
        printf("\n Saque de %.2f realizado com sucesso!\n", valor);
        printf("\n----------------------------------------------------");
    }
}

void extrato() {
    printf("----------------------------------------------------\n");
    printf("\n Seu saldo atual e: %.2f\n", saldo);
    printf("\n----------------------------------------------------");
}

int main() {
    int opcao;
    float valor;

    do {
        printf("\n Selecione uma Opcao: \n\n");
        printf("1. Deposito\n");
        printf("2. Saque\n");
        printf("3. Extrato\n");
        printf("0. Sair\n");
        printf("\n Escolha uma opcao:");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                printf("\n Digite o valor do deposito: ");
                scanf("%f", &valor);
                deposito(valor);
                break;
            case 2:
                printf("\n Digite o valor do saque: ");
                scanf("%f", &valor);
                saque(valor);
                break;
            case 3:
                extrato();
                break;
            case 0:
                printf("Saindo...\n");
                break;
            default:
                printf("Op��o invalida!\n");
                break;
        }
    } while (opcao != 0);

    return 0;
}
